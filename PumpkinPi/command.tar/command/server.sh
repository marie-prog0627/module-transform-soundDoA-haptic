#! /bin/bash

#julius -C command.jconf | cut -d" " -f1,3 
julius -C command.jconf -module 


