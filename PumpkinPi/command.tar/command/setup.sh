#! /bin/bash


#TOOLS=~/julius-master/gramtools

#cp $TOOLS/mkdfa/mkfa-1.44-flex/mkfa $TOOLS/mkdfa/mkfa
#cp $TOOLS/dfa_minimize/dfa_minimize $TOOLS/mkdfa/dfa_minimize

# old
# iconv -f utf8 -t eucjp command.yomi > command.t 
# $TOOLS/yomi2voca/yomi2voca.pl command.t > command.tmp
# iconv -f eucjp -t utf8 command.tmp > command.voca
# $TOOLS/mkdfa/mkdfa.pl command
# rm command.t
# rm command.tmp

# new
yomi2voca.pl command.yomi > command.voca
mkdfa.pl command


